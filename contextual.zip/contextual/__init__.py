from contextual.context_encoder import ContextEncoder
from contextual.context import Context
from rediser import redis
import numpy